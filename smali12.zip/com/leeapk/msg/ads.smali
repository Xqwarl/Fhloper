# classes7.dex

.class public Lcom/leeapk/msg/ads;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    return-void
.end method

.method private static GoToTel(Landroid/content/Context;)V
    .registers 4

    :try_start_0
    invoke-static {p0}, Lcom/leeapk/msg/ads;->goToTelegram(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_8} :catch_a

    :goto_8
    const/4 v2, 0x2

    return-void

    :catch_a
    move-exception v0

    const/4 v2, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v2, 0x2

    const-string v1, "android.intent.action.VIEW"

    const/4 v2, 0x0

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const-string v1, "https://t.me/+XrVnHWA9IKgwYTgy"

    const/4 v2, 0x1

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/4 v2, 0x3

    goto :goto_8
.end method

.method public static ShowMyMsg(Landroid/content/Context;)V
    .registers 6

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x0

    invoke-virtual {p0, v0, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v4, 0x2

    const-string v1, "dontshow"

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/leeapk/msg/ads;->ShowMyMsgIn(Landroid/content/Context;)V

    const/4 v4, 0x6

    const-string v0, ""

    const/4 v4, 0x1

    invoke-virtual {p0, v0, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v4, 0x0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v4, 0x0

    const-string v1, "dontshow"

    const/4 v4, 0x0

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v4, 0x5

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v4, 0x4

    return-void
.end method

.method public static ShowMyMsgIn(Landroid/content/Context;)V
    .registers 8

    const/4 v6, 0x5

    const/16 v5, 0xc8

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x3

    const/16 v3, 0x14

    const/4 v6, 0x0

    new-instance v0, Landroid/app/AlertDialog$Builder;

    const/4 v6, 0x4

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x3

    invoke-static {p0}, Lcom/leeapk/msg/ads;->logo(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/app/AlertDialog$Builder;

    const/4 v6, 0x5

    new-instance v1, Landroid/widget/TextView;

    const/4 v6, 0x7

    invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x3

    const-string v2, "Tg @VibesApk"

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v6, 0x2

    const/16 v2, 0x13

    const/4 v6, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v6, 0x2

    const/16 v2, 0x3c

    const/4 v6, 0x7

    invoke-virtual {v1, v2, v3, v3, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    const/4 v6, 0x6

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setMaxHeight(I)V

    const/4 v6, 0x4

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setHeight(I)V

    const/4 v6, 0x5

    invoke-static {p0}, Lcom/leeapk/msg/ads;->logo(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v6, 0x0

    invoke-virtual {v1, v2, v4, v4, v4}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v6, 0x7

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    const/4 v6, 0x0

    const/high16 v2, 0x41a00000  # 20.0f

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v6, 0x4

    sget-object v2, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/4 v6, 0x2

    const-string v2, "#808080"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setBackgroundColor(I)V

    const/4 v6, 0x2

    const/4 v2, -0x1

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setCustomTitle(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    const/4 v6, 0x6

    const-string v1, "Больше Взломанных игр на нашем сайте Tg @VibesApk"

    invoke-static {v1}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v1

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    const/4 v6, 0x1

    const/4 v1, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    const/4 v6, 0x0

    const-string v1, "<b><font color=#10a3f3>Подписаться</font><b>"

    const/4 v6, 0x2

    invoke-static {v1}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v1

    const/4 v6, 0x6

    new-instance v2, Lcom/leeapk/msg/ads$1;

    const/4 v6, 0x2

    invoke-direct {v2, p0}, Lcom/leeapk/msg/ads$1;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    const/4 v6, 0x2

    const-string v1, "<b><font color=#cc0f39>Закрыть</font><b>"

    const/4 v6, 0x7

    invoke-static {v1}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v1

    const/4 v6, 0x0

    invoke-virtual {v0, v1, v4}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V

    const/4 v6, 0x5

    return-void
.end method

.method static synthetic access$0(Landroid/content/Context;)V
    .registers 2

    const/4 v0, 0x3

    invoke-static {p0}, Lcom/leeapk/msg/ads;->GoToTel(Landroid/content/Context;)V

    const/4 v0, 0x0

    return-void
.end method

.method private static goToTelegram(Landroid/content/Context;)Landroid/content/Intent;
    .registers 5

    :try_start_0
    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x7

    const-string v1, "org.telegram.messenger"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_e} :catch_22

    :goto_e
    :try_start_e
    const/4 v3, 0x5

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x4

    const-string v1, "android.intent.action.VIEW"

    const/4 v3, 0x5

    const-string v2, "https://t.me/+XrVnHWA9IKgwYTgy"

    const/4 v3, 0x4

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const/4 v3, 0x6

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    :goto_20
    const/4 v3, 0x2

    return-object v0

    :catch_22
    move-exception v0

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x5

    const-string v1, "org.thunderdog.challegram"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_31
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_31} :catch_33

    const/4 v3, 0x7

    goto :goto_e

    :catch_33
    move-exception v0

    const/4 v3, 0x3

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x1

    const-string v1, "android.intent.action.VIEW"

    const/4 v3, 0x2

    const-string v2, "https://t.me/+XrVnHWA9IKgwYTgy"

    const/4 v3, 0x5

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const/4 v3, 0x1

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v3, 0x0

    goto :goto_20
.end method

.method private static logo(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;
    .registers 5

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v0, "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAAIABJREFUeF7svQeUXed5HbpPv/1OwwzqEAABkhDEJlISqRbJNiVZLrJlK1IcO3F5tvPsOJGeX7xSXuI4cUviPDvx83tW7CT2ih3Ljpeal2wVy+osIimIpNgJEETHDKbefurD/v7zn3vuxQzqDDAE9a9FYubOLeee8+/ztf3tz8C31nqdgUkAuwFMA9gOYCuAKQATAMYA1AFUAZQAFAA4AKz0YCIAAYAugDaABoAlAPMAzgA4DeAEgGMAjgA4BGBmvb7IK/l9jVfyl1+j785NfweA2wDsB7APwE0ARtbo/S/2bRYBPAfgaQBPAngcwDdSMF3se3zreUNn4FsAufQt8VoAbwRwDwD+TCuxkRety8MAHgTw1fTnjXy8G+rYvgWQC1+OW85urPsAfBuAt14Dy3DhI7y0Z9DSfAHA35wF+mcBPHNpL39lPftbAFn5ev8tAN8D4F2py3Q97wq6ZH8J4C8AfPF6/qKX892+BZD+WXszgB8E8P0AdlzOybwOXnMUwEcB/DmAL18H3+eKv8IrHSC7APzds8HtD70CLMWlbhZalv8J4I8BvHipL75env9KBcj3Avixs1me77teLuQ6f4+PAfjvAD6xzp+z4d7+lQQQ72zK838/Wz/4qW9Zi8veh7Qq/+VsPef/A9C77Hd5Gb3wlQAQ1il+DsDPXgcZqI2ytZgJ+x0Av32911muZ4BsOVuB/nkAH8hVqDfKBrtejoMV/986ywj4jwBOXi9fKv89rkeAkMLxTwH8k28B46ptWQLlP5ylzPx6Som5ah+83h90vQGEoPjn33Kl1nvbrPr+dL1+NQXLNTuItfzg6wUgf/vsSfnX3wq+13JrXNF7MZjn9fizK3qXDfDilztASA785W+lazfATlr5EJge/r9S8uSGPcjzHdjLGSA88f/2mp91fQYTfSSm+sGIBw8tSR/P/+2c1wLI3if/8txrz/nCQ59zzU/IigfwL9Mb2cY8uvMc1csRIKSE/MZZ/tDrrvnZ5tnj3uWmNgCLoSpsyD9OqA6P+5fPCdjuAZi2gTjx1WP8L32a/JHvo/9Tz5b/W+m/w99XPkc+4GUBkq8B+D9fbhSWlxtAfunsbvhX1xwY+gB49uz+HrUS/lpAhBih6ffbn/j8wIEBB4nhA0ao/jYMEL3fh63Reb/wywIc+W/wb87eBn5xw1zDCxzIywUgt57txPt/zlK037KhTizPnptagRjwEj7Agj3QM7swRgwkrUR6A+3YTS1BDyESRHnrk1qgzL3SAMlfHf680tUiPlZ0yzbUmRo+mC+d7Yz8hwCe2NBHucop32jH/JMptUG3o26c48tv2kQBJIQlFgS1GG967b346oEHkSwm8OJzd7cAJfO1hi1B+rt+Wf6zdEiivauXH0B4Dekhkvrzexvngp57JBvdgvzu2QrtT2/YEzh09jKAGCGsSRPf9t2vx+c+/SDik4nEJ/aQCSBA1KPnBuFJGlcI2HSssZIVGYhZNuyZOt+BfQjAP9ioR75RAcIuvv8G4N6NeuL0cZm2izj0c2oLJuCZMMoRvuP778HX738Mc4faAEMSiVHUKVfg4GIQQ+9pECQaIPnv3wdL/tGXXQyy0iV94Kz4xI9vxO7GjQiQdwP4g5dNNdywYSX9VFRk2EBJBeH3vfdefP3RA5h7visAQUgwhDAtF3EUw7RMxGGoUsKSBs5vdhOW/K4AtBKIFND42dcFSFiF/1EAH99IN8WNBhASC39zI52gizkWHRwlJlO4SSbiQ4A8/s0ncPrpppDDzSgHDA0QpnzzSxuWC6R7aXFoZZRVuS4Aos/CB1MC5MWc+nV/zkYCCGsbZN++LJfrmPCDWKVuWfKwgfvefy8OHTmEgw+dBjr9WoiyBqoukliUvbqINRyIx/lI/SJe//J6CtnBrJlc87VRAPI/APzwNT8bl3MANB861apTt5SBS12sDCA9G0bPRYJA4pBIxx52qAqHgpbcAax2ZfIpYX42PayXZxbrQmf7jwD8yIWetN5/v9YAYdHgI6l6yHp/17V//6FKehYyMGwwgTe96275zK984pE0SLfTOruqlay06DKpAD2UPKip3TZldrKq/QAork+A8BtTbeU917J78VoCZPSsIiHJbBur+HcpMMqlXV3LhB+lsQDv7DZw5303YmLTJD77Rw+IlfECdboTx4ARcFd7sKTSOLgi+GnwrYJ/oZSkn2WmWbA4SSOfXILgUg79ZfRcFhWpHbBwLY75WgGEbbAUALj2fKorOet5C5KPkxleFIE735oC5MPMYqYrH5MXoWITZreSuE9wFAtkA2ao1HkNQAAYmmJB8hXT6zBIX+mKkMdFoQ1qEl/VdS0AQnB88qxQ2V1X9Zuu04epOgjr5wohCX93FBlx6tUV3Pm3bsFn//DriDp9BBm2gSRc2S/K/kazoYmONCRprEEL4thE1tnWMD9GT/LH11UWa7Ur9ehZ2dTvutogudoAoVv1qZe95cguoaLkKo9KcWsD20Fs+eJile4wcevtu3HgSwflb17JwMjOKkZGCwiLFHUHii5NRH91/ALsThuLC10YbeDE88uIW0C8kCiQ6KA8y2Lxta8IgPCL0pK882q6W1cTIIxMP3PVY448l4mnePgby74eLtLpDTtEAZGCnvqbcnNUEY/gEF6VZugWAXvCwMQbanjPd7wNzyydxpRXRLfYjzc6JfpWg2vJWEI9YUu9WsV2EUuLSyi1QizPNnH4+RM48dQywtMpWPikfJ1wwCjl0sDnu8rnDfDP14dyzYDJmOTtVytwv5oAoVtFrdt1WitdzBjiAkW+Kt7RGykDt+7dh8NnXkJjpg0vKqHnS5lb7fo0ZetBEQ9ZkBNaiJGomED+bsLLguueBN2+ySgccPYAe96yC1t2bUavpKSjqiMcAwIkwRLOJIMWw/UK6Da6aHmLsOsquxW2u3BQRsFXgJowePCA14nQbFYQHl7E818/glNPtJF0+mBxYSIK4hydxVKsYdLr81dacG0DQb4ZZShdLJX9iwEIY6eLuKRrm2ljdovu1rqvi/lqa3EQV6HOsdrFVBtX7rTcb0y/3nMv7rz7tfiDD/8+GsfaKBXUBmx3ulnDknKbCpJNYnI2sGNFC7FSd4aWh2ePm80FnJuB19yzB+WbNwkw2nYbhWoBfq+Lrutnm50/M/6O073Z63RQrBYRmBFiv4soZZZ4bgGWb6HX6RcSq4kaOULABLNFJDMNHHzsKI4/3EC0HAt4zcCAI4eY0u4JDgJ7uK4YmTBtW9089C7Ib+KsAzJ/XvOuXO7n4V2k09H5nbO2AOE7X5U6ydUAyFWukA8CxXUAP0zvcilQjKqBN377Xbhz9xvwPz/x+5g73lbZJG5O3vQToFQqoN3qigUy+PqUUCiNUA5glFWgXb3FxKvu3o3dt02LCzXjzwg4TBdoGItwnJIAQi8CIb+c2ELJLqPtNeXhwPFhtm30/C4cU4FEHkcLSNPEGiiFdgle2xOgHHj4OSw9EiBpJFCWRJ0HyXLRuuWutGIWq5tCiG4aPQ3dB1fbGfnHMzpM6qKu9Jq1B0b+QNe94r7eALkG3KpBgLBdlRFCZkVym/VN33s39t56I/74z/4M/sHcleRb0BOiVwUDRmxJnCGulKvAYm83sPc7d2auVDvgdDQGDgWxHMvJMmgdzGIsVoEWgYuWg4CxHBMlw0PFGkGz1VKvLQRIPANBFKHXVu6ZtjR6VxBQtCpxqC5d3apDA6X17Cwe/dRBhMfVd/ESuo9dmGaiOGLsWXFLkv3SixZSzs9KcVh+d6y2U+SthmK4lSzIEP7W8Nd15W6tJ0DIymUhcH3XOe5Bv4/7nF6K1B2SWEQ2M3Dnu2/AHXvvwZe+/AUcvP90PyHECx9ogCSyoX3EoPXZ8YYa9rx5M3pjZbEWy705mI6NWqEu7lQQtAEnwejIKBr+ucF4pVpCyavCapmYf2kR3aU2Altt6sTuYmLbZgGLfm0eJAQIVxstlFBGp9GBEQCVnofRYMugNWE3I2x4iTsAiv4FSbsbV23aGrp0RnrzYeckYzLpoORnrJZFu2rZNRYS14UFvF4AYT8Hq2PrP6fvPADh5VVBtkr1lMoFFWfwNWV18Vl3uOO7pgdBoitxvLHHgGub8OMY1oSJ296+A7e88UYcsRZxujcLoxjCKCbiShEY2qWK3Ei5SSM2QpIYBY8FFAsFAUdnpoPZr53A7BMNRLMhrE02ypUi4kqI8h4P1qSH4uYCbMdBGAQI0jqKWJCwJVbJomG0+yDhZ2ignHr0eTz1sTMZSbLEu4G4XLw79EAPLI65uYeD8ZU2tbbK6mRroqUA+qLqMOsOFFLl2Tu05tOy1gsg91+1ZqcLACR/D1SuBBRQul21N4oKJLd9+zRec2tqSb6SFmy5l9Ke8/E9Jex/5w2wd47glH8SHbcBa9SFmd75+b75eIMAodXpiK+mwME1abNOChx+6Hkc/eN5RLMGosVYYhpnK7B5Zw3+VAx7wsXoPXXYArBAslPDiwA0Gia8otr8dOm0NenMRqif9vDwJw4iPpHAiAkROoo+aDdQDFXiQmIV3hG0i6k/Z7A3RZ2s/nYRAQoZxDtsQS4iqFcoU2vtYhTekN9wzkm6wgfWAyBXt032EgCi7qBp/wRfx82fqpIYRQN3vGk37rj7bnzjkUdw4NMH1d9CYOqOCm5+ww7Ym2M0nDYWXGSWQ86/k0haVgfjDLob5nIGENsxYdkWzI4lANkGA1996Dm8+DvziOcSeB2mlBNEHrDlnjKSHbZYktobahjbOYKW0ZLXEiQ6huHH8mcdk+h9wNiEILEbDibmbCw/E+GbXzqKaDaGZzMmod8YyI1Bbv5SsdeBWR8c5xMAYB+9iu3OZ22yI8pt0RUyX2sHEH7OmrfvrjVAKLDA+RFXbw1/g+yE92MRfTDnXtA0u6Prd57iTxEkEpM8dBo3vn4KE3urSKa6aJZs9KotGCVbNiFdqzxA+LMGibYgcTFCrxPAKzpwwwLc0JTA3D7VxWOfO4hT/6uhpqBzjxYBq2iieruNLe/ajNr+kgTtwwAhKPLZsCBWVsrqGBK8a4AkSwm2+HUcf/IMDj4wI5ZKxdM2wJS13DFWvuOvBBBaRG3J9M9SZ2Eyw1QXIk7FKZgaX7GvPm891taC6MvM+S9rJgSxlgChNM+Bq66ofgkA6VsQfS4VTYQ30VLZRtvvZiRDsSTPP4iw1EVp2sJy2UbXaMGuuEiY5tUAcRKJBxgw65W3IARIFEbwPA9hFCJZNrClyMkMQPegj/DAslBRghOA6RgCjq33bcWm/aNYLrbg22rz04LI8edcLVqQDBxap65jyrElHRtux8L4sgl/zsThR0/h9DebympwiWtlqiJifg0wBVS2zXZd9Fr9Aic7JwUMzIwNZ6zk9crC5Nc5CRP9x7W1IOoSA3eulaTQWgKEE1KvPnV9VYD0QTC4A/K/sSJuw4cJ5qi8PEjefQMqOy3M2gGMupFlmRiUEyCyDdIULusV+VoH/8aNJfvQ8cW9SlxV/zB8SyyJY1mohnWE3R7C4waYJi45Y+iW2hjZMoKoHGMhOiOgIsCcQJm54Vgkn+FioZG1kqTD/xRACrM9OM0yzjzfwKFHZ0CrQs+IAhJ5Gv2gJpfe3OpfWxIdyjXNiovyZVboUckY/4x3NNtS4JSe+NRqa2CtPUD4OaSjcFLxFa+1Asi1Uzy8QoAYcOGmvd2mEwplxN5pYOK1NYzsrSFw24hLgGWVJAVL9yq7+VX7PrWuc/iOLwE5gaFXHiAaJNz0fJxg4aqXVMKv3WtIHYSrETTENeNzuTRI+DODfzcgk7i/B/IAYQxCMNhHAnSOJHjp4IxwuFy/7yYJ4PKbnA9kFJN+xspg1yN7XYSJkAb3OUXJ7AjS8E67XKwf9cuiQwDJTuIV7+HV3mBNFBzXAiDUyiViN8a6IGD0YSoXg3dHLsu10Uva4mLtf8cUyq92cMpswKrZMD31HNY6MuthJ4jSGMQoD7oTDMrlPe2U0mjZ6PVU4c9UJN6BRatCEAROD4WkJNbGiZRLll9dow0nSPlaQSwAMdqD0QIzWVi20T3aRnjGx/IzLVjHCmicaMNi8J6mj3q6sSQfZ6fuUZaxMhJRXuGKDV9qQElPNaQwVoqacV9bmO+TYyJokOiYJAfjQe7W+lgQ/XH0aK5onPVaAOShDUVfvySA8Jraqk5CApMLjLzRxZZXbUPDW4ZZCeFsUq4NwcFFgDC1y5QuA3H5mw3QcnANg0PHH/wbQcJYJLD68y8JDtuys8d6gfobgaABxt8JDr34N9ZWtAVh0E5L4i934Mx7WDq+iOXDbXSP+IhmDMTLiSQClDRqX5NLB9j9zZsCnQVBzd9itovA2mJg/13TqG8voeSU0Q5aePzJg1h+KpBM3EDvCk+L3vh5VXsFNfVxa5/mHb7v8HfS41+/0h8u9rErBcjGGEGQ/7YX+kZDlHABCDc3G/jGDez/rkkEWxUoGHuozdkSK6ItiK47SMU8rX8QLE7RzGIOfUgESM2qDVyPnt3LrIN2sRiMEwSeoywELYgGVf7Fuuhod1xJ8WqSY3zaVVbjeIjlFxvwzyRIFo3+XZ77UjdhiR1JgZ9G7ZGOtvmVNTjS3vob3zCFfW+bxubpCjzXRqugeGP+fISDX17EC/cfU+J4OuTQFPzMIq2wHfV4iPW1IPzgKxq9cKHtdD6gcXjNNy8Wiev2vPPdiVb6dkMAkXy+FQoYtn9HDZWtY2I9KqUSzJKFxIklQM9XzPld3KYrFJGCq+66/iYTSSlCXAqzOz83f+yFMHvK+jAwl01vKyvhhR6MXiKpXA2afDDP5+j4Q58/bTlIYtRWI2z68F+MxGr0XggQLgL0FsUd0rUOXTTnJk76ANHvyyRFFrQTIDxk1mXuLGP/t+9AaZsD3zwJuzICx/XRC5sw/DJu6N2FBz7yBL7xlUNKqFvHIfI5fPdB9zPjbV09gPAgXn25Q3yuBCAfveaTnXSAyVMwwCzVlz3HYtX5ekN9ZTNmJTiG5cTCsRrfX8Ceu6axXA2QjCrfnwDxi1EWnNO1Gnc3Y+nFRcw/M4fu0R6iElDc7KD+2hoKO1RwzjiDFkADQ4ODIKB7pa0DAcLFoJwWRINDu1kVs5bFLvIegZsVC2k97EUXM4+dytwpWozYT8HBPpFumlBIXStKRCjaDf+j7dSZJjWDhMxeASWzdNzXHnDr35nCln11mPV5FMdKaBk+HDtG0lHnKF424Xa24fN/8AQaj6UxSZSqsQxQWeJMKVI5pmmPyvpbEH4YOYHffzk36csFCGcC/unlfOCavmYVgAxUeXmnGrYyEmeqMjm7AGk9dt81idJuYGEkzKyHWIYUIFbNEnAsHptH8/4lnHxkGUnLgDGSYOveGpw32rD22HA2e7LR/aUYY4URsRC+HQ8AgO9b6Sm3i+CglZEtkwblfD1BwliDMUur2ZF4g6sa1xAuB5g/OYPWCz00n+iIO8W2XCMwVO97KgRhkKSYLkJD1SZ6kAA9W444XIpTpVbkkX4cwqwZuPU9Y5i8pQx/tIFK3UGpVIZXGsH83AKSCGg3luA2K3j248s48rkl1XdGBorOkGVZMQUQunaqAY2FpKvaLfy+y5mZeLkAeWpDDMy8oAWRe1zfymeBowJIxClQJuDuNXDT66ewUO3Cq1owSoBbLGexR80bl/4O3p1Pfu4kzjy8jPBQgpJbQBtd2FMGpr63js2v3YzW1oZYEAKE5ENtRQiC4eBcxx/8G63JcrQsG0sH8vmAXVK8LQPhSyFw2MLJp46j+VIgwBB3iiIQvDWnzZF0o1T9QpvWVDUlX+LgqTFcCTks4VXJp6NndMXFsncY2P/dCiDOVBNG0cb4ls0Yr9dw7MhxdPwQncUY5pKJM18yceDjL6XkSMXuUkkATYZcASD8uKtjQfhJHCz6qtyd4aJ+vByAcNTyv7+od78aT8p/gxV93lzWRD/XAMzEQOwxtjBQv9sZyFxZRQtw1JNZ/6iPlsHWWLpWhz92BO0nYljLKmWqe0Q2v7+KG75vJ+a8M0hKarMxZZsHAR/TLhathY5RdDFQ10U6bI7KpYlZRY+XDHRfWMLMQw3JThXmSmg2OlJ9j4NkwP/ndzPEvVEFyzBK+0H4QP6mIrd5TclJ+1xQGADIXe+8Ec6+FmpbewgdF5t3TGLrtnEcfu40mu0G4kYLwekKes+X8eU/fGawEJkBRN2odB+/JASuvgXhQfzCpY6ovlSAUFHg8FWhsV8suFZN6+qUZV9oQTaHvoNy/ziQouCW22uItxpiPUI3lNoHl85cTdQVA/fow0ex9PkFNJ6J4XVV4xFld6wp4IafGsWOe6dx3D4lAGE2KpaySln4VzoQH/5aBIy2FASU7Nm0cl7qVeT35YNLmHtmDv6hAO0TKgiXvR4Y8Jou2uRV+WnNhBbRVKDQIMl/phrYw157NQ4uq3OkIxwIKMMoSE3InFJZvZF9Jqo7FEBGJyvYtXtHBpAk7GH5JRP2sQl88Q+fRMxiJHkJQaxUIbPBQXmA5Prk150JP3DGeeZ2Ali63O11odf92tms5z+90JOu6t8vABDppkvvphlAtFl3FHt2fE9V3CtrPIHDPu20mEeAjFTH5evQgiw8OYfjB06j83iA8GSi2nMrwI531jF9341YnlhEp9yBWzezGKIeKsEGxiHMYukMlrYmBAf5XVbPkNcQJOWkjGKzgOXTHcw+M4ulZ5XVYBDOVYyKQteXQh3jjWErmnNb2MuSX2GSgp8FcYnPcvMSfVUrEemixJf+l5vfMYbN+8dR2h3B95oo1R3s2nEDTsycQrPVY3FHAFJf2IFP/eEj4npqgPRjP2FI5izINQMIT8Wvnw3E/tnF7tFLsSBk2B296mTEy/0mGelOZ2rSO5om2DE4rxrY+5YpuOPI4o+krhm6RmZB2Clo1xwJjjsnujj61RMCkmgRqLzFwWvfdhc62zqYsU4CmzQtxAPBUQhUr0bX6QhIdECu45HI6+9mY8GQTFVluZ5lyuYONAQYjH/KVhGtiD0f57pVWderpq6nmSuZqqtnkGis5NntecpIVicxRZyCyYt93z2O6s0uJnZbQL3HAAnT26bQ6viYm18QgCyejDB6ejce/vjTOP0NVSORm4eYuX6c0Xex0njo6gbpeifxW+44O7ns5MVsrUsByFUWX7iYw8895wKWhBmchMohkkFhgACYowb23N0HiOFZqE1U0ewuwB2tIYracnd3a2qTVwplmD0L5oKJ4MSMPOZsnYS9LcGx3gmQckLuFOntVacqrtUwQPLpXL5eA8Ru2MLYtY97YjWaBxpovqBiGQ0O/txYaPc3X477JE8k7dwa1PolRUQW9/yIiYmdJWydmhLNYK7OcoCnv/kU5o6oKVjSQWmqDkrWEvd/t6LdjE13UZ4cQc/pYWKLsoqzMw1EQYLubITx+a14+LMv4MiXltTxUVxSBgUx76wOQZNixM3T2cWr62LpDXPRYg8XCxA64cc3pvVQ5jsz5/qOdY4Fka2mrlLaJTj1mgompsuYq7VhVS2JQVy7JARFz65KkTBkXYT0kiIbjhSlnQU6rVnFHnRW0cNiP02quwf5XAozcOlUr66W3+B6qI9Wceq0JwRFa8ZTVuOxBbSea6BD1m2aWBpwqTjKLcep4nurYaApDqgDRmVHDYqaiclbipjevwWbto/CK6sd2UgaUsOwmxVEcw4+//kHldiDlEhSzSwHuPEtU9j15lEYW1pwxlooj9fhVF3YpofF5jyM0MLSMR/uXBXHv7qEJ/9SzUIpFakKQ0mhYbG9HIs4BbXetVfxX56ubRcjY3qxAPnlswmYf3EVv8AlfJT2G3I0an3is3qHejtpudUAiQe799x6Aa7L/vNBgLBS3qj0Mmo734f0djJnCRiKJ2i6u2byDjcVOaOWZK90vHHnyCY5nkNHfIk1Zp6bGwjCGdxzERhcdKuET8Xklkj2kIGsWMA9qM5FEa7TywOm9lWw89VbsenGuoDC9epoxXPo+h100EAUJoh6JkrtMUTtSFQbj96/LLJBgjbuDBfY8roy9rxlCoUtoaR6CRCzYMHzSgIQlm6ap1pwF6o4/mBb9cG3AM9KBfl0v0lOdDur2F87gPCTf+XsvYVUqfOuiwEIb4GnNlTmauArXRxAlHiDEpWW4U4epFuwNa2sB90rAoRZLAbq2oLkaSZsrdXCbhoo8m+uwy/fF0LA0OXSREO6awSH2QnwwmyC6GiC048PBuF5d0oCcQrC5bhNbJu1/D7lvu1IvlnVc3YZ2H/nNEamq5KOHRuzsNBewpI5hyhaQqtrw6fLIyqPIeyohGDBRLGt5E6f/PyLmHs2nafI82QDzj7gtrdOYWyPB3c0gT1BWaMExbKL+eUGIj9Bdw4wZ0yceqyHb/4v1XPC+kosemRpdm0lgJwzl/FC23VN/86M1uYLSZheDECugbbVxZ6IfG90WhDMV83Fo1JjlhmDiBI6lRGpCDJiYttrqyKQoAEi7F26F8RP6mJdCCBahkcfMcmDeXavronIezoeJrFNFE1mDp1A6+luVgmnO6UtBoGR1TZSDzLrN0r75OXzTJWmvvm2SWy5dRSbJreiXEmEUDiXzGGxfSQ7kQ2dyePLfEeAYnVdsSK0WGbTwsJLgWrNZXaMrBMWC3cauOud21G72RCAGONAueYNACRohEiOuZh/oYdv/PEsojNxCpC0Yp5ain4Mkh68HN21CULSE3NBTa2LAcjGqJqviJl+a6e4T9xMQwChO8I1DBB7m4Hdt01hebx1DkBiJ0HBrghJkU1SZPHm+89pRehWaeuhD0232vJ3Wo889Z2pW9JOwhlg4ZlZkfuR1G3LQLGbjjNgw5QGB4mGojqSfqf0ji61my2G0FtuvH0HtuwtwR1TW2+2dUz+NWwPrE8sttsYKZXQjRNEcYRCGCAKi+h0Qxg5gcfekoXeXAfWMx5pAAAgAElEQVSFcFQxc7UVcfsMZ/KxnKkOkhELTs1FvVRAo7OI5Z4Pq22jc9wHjlbwwJ+9KKleBGnbJQuCGxcgF6yuXwggHFqyLoJcF2sjzv+8iwOI7o/OW5Dx3SWM31xbFSCspOsuQk1zF4kfR0X/WsUkL56g3as8OEgbEdbukg3/aAPHH58VqxEuJYi5d4Ysh3CpUqFF+SBaDFq8iglvD3Dr3duwe99eeFs7iCtAo8HciVptw4RpqrbcKIphWSZ6XSpC0NMpIAkNuKElAOEqWg66foBWowc0PFSCETQO+jjwuYOazyifu++7J1HbB4xuc1CoeTDLkQTq3bCHJQptk618sovw6AQOfOQw5p7spkOB0or5agBh3wkHB11bK0KBQw5zWnFdCCDXnrF7XoSwI1C5RFl8sYIFGQAIG6NMYHxfAeM7R7Bc4UYLoYN08rBoQaxCObMeukkqO5SczA8zWLpZKn+otB6sooeLISpRrV9kfDpQVoE32BQcA1ZDayOItJCByh4DN9w6iZtv24bqLldAEYbLEvC3kxCuR2G5JbR7Fhw2mrP5yo+koYrHIPR4PWud/eqhDcuPMpAERg9o2QiaIZzlMmrN7fj6/Y+p/g4bMLxcLWRHEYVxA91CD6WagyiOBwDiz4zj6b88hpP3t2AmjEEu4GJtDICcl+l7PoDsYqJlbe706/kuOUpJnmeU9iNoF0uBiFKEKUBuLqC83YM/AgGIU3AyoiIBQguSb5LKWw9tQQiOfLyhv6VO846FIyLI8Pyjz2Lhay1VCXewukvFN2CING1g/23T2LJrE0Z31yTYZpNSw5qVj2AtIowTWLGPIDThFhzEkYUw6ApAZEUhgsjIVB3tyEUShjDjtGXXD+V3HbQHpwGj5cBeqsOfjXDgswfVjd1TTIEt+6uo7gG8MRumFUkcwtXstRE0TZgzXRAgL/31Ig5+icJ7NtDLca6ydgR9lnicvGDa17uEWOQc/t0V76/dAF5c6V3OB5CN1y04/A3y3Cr9N14Imb6kqQ28DIpiLVVlFs5cNR7N22RlABm2IBogfNuVYhD9cXlFExFyK5oiL8oMFWON+YcaGX+KlfB6VMGS1RyMNSw1cGfrq2q46XVbUK+XMTpek2C7Yo5j16t24VTzMB556WHU0hkitCAdMxTKeTQs3ZOCw5SJPqLPgzgyM4BEsY+E8w6ZzUp8+ORxLRVUsL5Qgt8I8MKXZmV+Cq3t9NvqmHi9her2AipTIayqCy9yJN1LgEQdE9aCIYTF2Sc6eOwTLylwqbaTQQ9Kro+6xfT7U3KCfufs0jxVJpfK1zs3a8y6IpCs2nV4PoBs4OA8PRnD5EPZDH3uxOCwSxumbSqA2MD4kAVZDSDDvegSg7DvopigVC6h3Urbbs0C6mZNKu2zp+bQPLAoggns1cjHGXLXbXSyGYV6fAKLeNNbt8EoqQDklh23Y3pqGjds3YdRbwxfOPkZfOLAf0Uc+ui5pgDDciNlOYYl4FcAiJwazgRJA3bGI2HcA0EkAEndLLEi3arS0Xq6KTd49unf/LcmYG/uYWSLBafsoWBVkdi+ACTs2XCWXHgn6jj2eAMPffg5qaQLJysdHSHGgkaH14efl9gXOYx0qCNRV+DXFiCrBuurAWRjKZWc5+ZwbupQmephZcBs0hq/MQGyu4SR7VW0prorxiDDLpZYkjRIN9NRBnyMFXT6+uRdMUPFugZpImTdMgg3HWTBOGsc5FFZmxLsec04dt+yC9WxKqYnJtFodlGtFHD3LW/AHTe/DlV7FHWogqKPNv7k6d/BJ57+kPRkkA/VpXwo78M9DsE59wQZEWsePThwJGDXViQPEAFNV52vbsdBtNACep68p/+ii8e+fkhmI3LW4qvfvhXeFh/FzSacqo1KsYDYisVFa3ZCWIsuCvN1nH60g699+KAqONKjTfQcEjX3XbEZUndK7v46j73CeLyMpraKFRETuGY9JSsqoKwGkP8E4B9dkdG6Si/mqDS9VHPQIJWBcWv2mOxyFSBXN5cwedOFAcKXUAsrE6nOBei6ih63eghO+Og8HYjVYIaKq2p7aIQ9AYhRTrB5Tx179u6QIt5oQXUUEhTbt23Hbbvvxc2Tr0bRH0Fj0cemGmtYTNnGmLcP43cf/td47ORXERTZwx6hG8eIgy68uKJikcSFqT2qCCBAZP+ks9uHQcJgna5WzDFskSkAMRoJwrAtwTqaRbzw6BHMPd+VAuTt794Cc0sX9WkXQaGL0foIEltlw5aXQ1gNwFksY+bZDr7xVycQHjYUSAIaDgUSxYSLFSdOK9cNN0zlkyz6wg70+aybKsp/Pjsc9B8Pb9vVAMIKExmPG3qpMWn9rxBJakjL2mTU1BQV6e7hnXcFgOggXfpB0oYpHaTLRkvlfvTgGiqbkLxIhu/ikVm0nlRqIhociZtIPFLbVcXWmy1svWUME94m2MvU563j20bfhy1bpzB5RwmuTX+8Ilmvz37iy/ji/Q/gP/36b2XnfgbPC0CemH1YAvREhoUmCNMpUgaJhbllJra4YPphgkQAwvt3YAy4WQRI0rPQC2yYQQ9J181qIlRj5MwUkjpf+wPb4e4KpS+kU41Rq1VgF20ZyNNZaKK3ZKLXCNA7HeOFbzTlRtF9KVGSQCQBS19IqtRC/0u7SnmArLYbB6zEsAjEJQT359/NZKpPXwxAKNn4hQ2NjPTgVgJIJKLJaXGKQ15kdxuqQQiBCtQtXyrpO2/bBH+0i95YP4s1DBC5i6dqiqx5kfrO3hDOHmzPtgc4VHyuXTewa+smTN60SSxFMpp2NwG4cfQm7Ni+C/fs/jbs8vbBRV9Fjm7Uh//bJ/HXn/kMxkbG8IEPfhA333yLtPSeDB/HH3z+t/BU5374TpoH9rys2MeM1vBaFSR8LmOoOJKMVtBrZwCRu3yrBWNBxSHN2Qae+dKsVPVJex9/jQN3q4l4pAW3zhuEJwCxSWFpheh0ApQTF263JpJAyycSHD0wg2PfnMXcC21xuWTWSqovrBqqUnb1ShtuOFs1YElyrtna1VHeCoASutlaCbMbm9Y+dCL7MYhOG3JHpxsm4wExNWmqvLyiwso8Dgo1XAxAGKhXzDqa8ZL8yzV37CT8Z4G5p5ZQYFPSVht7bxrH9p2TqJTUnZKV9fHC1IALlY8rwvkCxupjmF+ax7/+9/8GBx55OPt2/+7XfwW3332P/E6A/MpffRB+QdU/uMSShD2pmnMNg4QAkXtDakkyK5JmtBiL5GsirKx3Y1sAwht8tGSg0BrHgYeeh38kwfRb6jJVK966DGOKrb4F2CUDu+skxQKdoI35xWXEHQOWUYDZ7sHrTqAS1PHEwy/gqQeOSyemFEF5GWKlqdJbdUTuEPlUvkxeSmhdAHIODX4lgGz87NWK5i0FCMExPPZY5PnZm8AiQ0pJSTWf7CkbQVXxsbKW2yEXi0LQVdPCaBlozEU4+uQiWnNqo+6cGsXUNsWDMgpNNNs9TNbGcPuNd0kW6lU7XodJezsqmFDp5lBZN9+OUEIBC/Pz+Of//J/h/ke+gvqI0uedPXoEP/QTP4Wf/wW2/wMv9L6K3/rMvxqogxRdW0QT6G5xc2uA2CazU+oGkbci5wMILUonCsTNCv0FFO0KWkcCoZ4cefIkTh5oZfpY9o4zsKZMtG0fTqmMUmSiVhsVIYeu38Wp1imJucIOT3UR0WKCSlzDmWfbePJzR+W96HK5sdIITrUpV1CD5zfINVbpaz4AkvQ5K+6Hy3rwnGzWMEA4Oo1PevksnerVcy6GJrrKXYehiW7X4I0n7Smq3mpiZGc1AwgZvR4Lh2mhkFQTNk3tKBXRCGwYc8s4drwHMzAxPV3H5k3jqvDYMwUUtBbMQu3dsy9zoSIGqC1WvMmPMuEU0hmDLdV592M/8WN44KtfRrnkwK3W4DeW0WoHuPeNb8Zv/uffwsjkOB6d+Sv894d+QwASugZg+wgZYNhEhno/za0iYMJIOZRMAdOCyDZiW4aORZjq7Snf3ena6IaB0FD4Hr2khaAXw2i5YkU6Rxy88IiauPX2H7oL7s4Ay9UZ1Le7aKKHQuzApfBFtYJuVcWAwdISmt0eksBEMS6gOdOD7U/AW0xw8POnxG3LZpWwtpmoWJIxZH5sghowOgSStctarbbH9+VHuQ0D5OcAMJp/+Sw9PYzFQSvud8MRByZnZSSiPCJ3K4O+VSpYxlTvvgL8nTHK4x5iJxa6iWb0apCMOFUstpdhLBkYQYKRyiZUqgU4gXJhNm8Zk5oFs1D1eg3GqRpuumEvrLA/L8S2HQTdSMBxYuY4HnzwK9h/8+34rd/8TfyPP+IIeaBX8bHFmRCgcBEsv/u7v4PX3H0HvjbzeQHImcIxNVbBstGMWijbtvRjIBNGUJdNA4SWZDUrouOQuGtJAZEA4fLDQYCYCxWceG5OZotsubuMu97xKvRGTqPttTAxPYZu0oPthbA9U4J2p65cUFL6z8wpbYSCYaI3R6E7C1azgkOPnsYznz8tavMSPtAYp71sHE9tpXcwH9107EJ6zXiIOtw6N+xaqz3L7O1v6zcbBsgG516tfA5kupHpqBhDViIagvkMFzMoPPEd1tQtVSGmasf2O2or0k34LgSJGRioGT1UClVpMqrYNVSNqgDj7Xd/jxTyNnvTkoE6/NJx/OxPfABbJrZKoL1193ZsntiM8YmaZKzGqpvxr37xX+LjH/kodu3agudfOCFDaDiTveP1sK20KQMIrci//KV/i/f/+HfhCy9+BB/95p9gtnwMtqPMX8dUwbqTzk4fBol2u1gjyad8dbpXA4TA0JksAWrqZtGCsGjYORNh4aUOTn6tJdrFt79tGtv2TcIc8bFUnIU3ST1iZQ1LTgVeyUah1k8+dNrLiLoGoi4QdyxMxVswP9vES4+dwPOPLoiEkvpCqvKu6yZ8iNerh/bVtiID3KxhgCxs3MaolcEx0OfMQTi2Cce0EcShVJ31XHANDr6LzLtIqIKgtGeH4xDdVUhgOJ4pLsdEbUwOwPBVTn/v1hvwk9/7C+JKWa2a9EecnJnFd77r7XjuiZfQC9icpeoEtGSTU8o6vPDccXjlAkLfx+ve8noB08kzJ7C0qLJdC6fn1POWTuI9b/1+/PaHfxVffvLT+OiJD6HtLSOxFTW+k7TgRLwDp2nPISuiXS4/UDcNgiSriQRRlskiQOj6aSui070kL0rRMD98p5VI9u/Geydx0+t2wC8toVWdg12K4ZU9OGUHlsuAz0ClUAJK6uq0lpaRBEDkGwhb6RVrjiA42sHXP/cilh4JsrEKWOatzICFqgwcvQZuFi/EqN5teYC8NpWLX3knbtBHeTJZIORYsNixVMO4Xql0P004p7zqRaFmkR31AGc/sGVrHZUxR+ofTt1Eu2yjZLaQOD7K5SparYZYEPr3Y6UJiTm47rvzPrz3np+UirdO2f7MP/g5fOi//J6kM7moT1Uoemi31VTdW+/YJyBgjPG7/++H4HkuFlvKFZnrnEBztoWTJ05j7swyTp05hZ/+hffjfz34e3ig8VcKIIayIInREzZtBhA+mAMJ3SwuKzKFimIldjadilZE10NCPx4ACIHl9yIEfgirW0D3TARzvoBDX5tF45iyvJyhIhSZe7fB2hHAKgNOqQCjGMBlLFXmd3ZgOezSVIBYbrfRa0bKAvZMLDebKIdl+MdNPH3/aZz4YkNkUzlx2Gkol5hJDRYWB+KQ9XexeLivAyApxTxANnDn4Oro5OmXnmydCy8C7rSBHVsmYZUNLJ1s4szhtmpdpe4TA29mf6hmnnbkVfY42Lq5JqREqxzAovSPy+KgiuwJjkLZFop4sWCjaI5gvn0G09Ud+P67fxjfvf+H4XN6LIDPfupv8L53/x1x7zIxBUPl///FL/8i/va73yvPm9zEdHAdLkHNvW35aPpLqLj1bDQBayBNHM0A0iwuwUhUWte0A/isgsuLc8WzIZAQIAKooXQvASKPp/FHvmBYDUpY9GflfAUzDux2AUcemcXc0wFKZUuN0HYV65iie5t2ljCxtYpuuQ2zEKEyZcOpqPd3TVesq5fU0Or20AhaCMOm8LcSUvHbBZjLRbzwxZN45m/mhNoi96+0An+OBVnfLJbeaFmnYR4gHz6bwaLA78tqZRqwnO8xZWDfvZO45U3bhQ070zsjd6vTz87jyDfmceqJdkp/UH0kIdU/ykDpVlOKe0kxyqwIvB6SsgKIS+kfyxXeUaFcQMGbhB02JODcXtqF933nj+COydeLFTn87Cnc9x1vxeyxZe4OJImKFX7sx38Cv/qrv4bRsdRV4506iDKAtKyuNDM5hiOPcwWFQADy25/9RbyIJ5ABhJE5ae2p2LVmOSmw5Kg3kSEWZDWA5HlZGiClqIqwZ6AVNhB0uxKHxLMFtB8K8dxz9MAhvfs9R80DYc9KcZ+BvXeNYmr3OKJNHFkXwS8kcK0uqsWKNG5NVrbKa0/NnUTixghKDvzFNtxWAfHyCMZ9FwcPnMQjHz6ezY1P5omGXDuDfBG1PQc5eGu+ZSnM/n6+ax4gBwGQF38NV774ow+Djw03ZvcPUaqxViJCy7e8bQq775pCVGkCji/db93lHqz2CNrHA3zxY88geIFOMTOkpMDTpPSbp+yaopnQzSJAeJd0XBuJ24Xh2KLkQW6UpGtLgG2o1OW+yX34mR/4JxjBFIrhJvzdH/4hfOJPPynpGVqR/+2nf1LAMTJWQZT6/NpyEAzMbml1dTNKXSgLUkWfw9P4L5/9DxlAzNhAEpswvQRxz4BhxghylXRyZCUFnMtm6XRvPtW7mgUZBghTvcGigd5JC8e+2IDPtn7mlsxAtI01pd29UQmAs/PQqsUwqwEqm8ucMwE3nc5V9Iqol6tYajWw1GzIHBUjctFdjCTDVY/Hpfr+xY89igaDd152kqVTAWwFisGxdCvwNNdi/7IP6sY8QKh7ReWSq794EsRsaiDkT4AJIyW6ZTSRyBd3hT5qQg0oBtsF4NYfnsLmu120zTbqW6twmFoNA3h+jM58G/HSGJZe7GR3KL0R+Xo9/qAwAhg1A149QVIOBgDi2mUYNnvVHUSuJYE+VyHyYAUl3Peqd+Cdd/8gdtt34Pf/2x/ig//oH6Pd6uK97/uBLNagq0G/uh9AK3CoG6Mv4KEF0YtWhUXC33/kN7HonkQQN9AJurBdFvTY/GSk7P6UpKljktSKUNTtQhX1vIslPmfPyCSBtAXpLRnw54Dnv3RaKZaIOHZ63GwhIE2ZXLVNyoJTQKJXW4JZN7IsV56a4lL2tOOJu2WEHYQ9UvEtRCQ5LFroLEzi6598FIsPsqTPG5qDEgMfITzSqqsbz7kj5NZ0+5ItelpbkHcA+NSavv3FvlnG3szJ92Sv7QNEMk+hj1KaASKfhz+3wy6m76tjy71l6Vcoby7CqcSwjSIKroHm/DKw5MFfMDB3OMATf30SAUuhvBOy2YifVQPGt6kedcqQ5uMQWhC6CJZtMAd5DkBqFRPNmQQT0V68503fJ/HI1x/5Bu5767vwmnvuxO/9zn/FTTfvBgEZJCzIqWIhQaJ/p1XiyoODliUuNPCF8GP45EN/ngHEj30YFvtB+gREfboGgvZYFf648QSAq1BONEDymay4pzSz2EAVdyIQIMlygqcfmEE8q6wGLXB+DkvIgikTJEUILYWNX8ZEG8txEyM3VdSYO6ZIxwqomiUsLIeoOmU0usswEl+sICfaRR0gadloPOcLKzh4VlmRUqLYzxogMuNkJYfjYvfdhZ/3TgCf1tvzGo004DfU3mQ6UEXdTmVpyZ4skwGaaxN+FCvlvrArsz3e/kN3S/EqqAZS4aV/Xi7bov5H/dhksYVgvozuEQcnHmxJSyjrG1Q/F4Dw5kQVwddPwduSi0OqPXGx8gAxbFvcLMt0MytSdFWguaO6WWojpJf8z//70xKQk3Coi4T6X9JNNFD4MwuJXO1WE+WCUnTn6lqLGUCC2jwawYIIJagNHyOizvAQUTEbjJsCJF8slA2WCjrkuwyHU70aIHkLYi17ePLxIwiPcXLVIEDEVU37bPRkKma5brlvM0a22ejaXfibYlRGbBRME/VKVVLAZsMTq8jhpgFl/Ri4t4Bw2UQlrOJrnz+C03+pxOzMqG+1ODJvwOten6KhjErQAPmDsz25f//CoFrrZ/Rn5SW8TQyxNwkQNYVWBbqsH+h0Kd0qKm7c/QO7MfXqMvzicRkRFtcMAcjmkU2Y782g1/URzrTRmHGBEyW88KXTOPlgS+7oauR3OuE2FXLYvLcubpa2Ik6hIPwt17MU72kFN4sAIXGQsc6++n68683vlaCd8Yjf68mm52s1QAgEulsf/cRH8eQzzwmQaGXCrrpZaAtDgPzZyQ/h4UNfBgHSM5bh+xGCOJAUbwYSvkjzr2JDxSQpQORPOcrJpQCEIA5bEYKlWGWynjidSQJZkdIbIzjkpiUicankaKgG8Dg3A6960zjK0w6M0UDqJcVRTqjyYHmRFBTJBKYyiq7rhEsuunM+3I4tFv/xPz+llPT1rEUNRL0V810Na7s9//DsqI8f1VvyGo1yXgEgmk6QKvHlq+FiVh2lys4BlXe+5wZsustDp7QId8RBZVTVOopF5uJtkcbkWjrWQrzoCUAe+uiL8J9VEv1xShcJ2YZLwKU6tqM3FLNg3S4z3ohheTFMzxCA0IowDqDbR3A0uy1YnomiURRiHmntP3XfP8GIvx01a1OWraJLxUWL0fBn8aY3vBVPHHgav/Rrv4Sf/9kPolSuZPEJn9uxZ/Gxk/8D95/5OEw3ROzbApIW06y0BnmQrAAQPmdVN4suXNqnnlmQxBfqu7YgwwARygnV25lEywGEwDANPQvEUqlgq5uNj77pTePYumcC3dEl2IzzKoA5ksAdKWGUNyAWSKki2eqh1YhgNhI0D7Xg9Ebw9CdPoPlCknUoDswEpQPCUHB9LIiMkNYAuUYV9FUsSC6VpwGS1RToDpkQXtC+d21HMLoAjBgYoxp70gVZrpyhR982jHrC5glP9RCfLsB/royHP3EQ8UkljWmEvC2RdB1Kulf6FfYa2LlHKb7TirhVD4Zrwij4mRWhWAFBY6cTbpkJsxh58u7fcsSSMGj/e/d8QFi8nRZjp77rxOeRk/XBf/QBPPPCU/iHP/MB/Njf+1EBTt7lYqPUp09+JAMIX0da+VUBSBRL81Tix1IspAUZBIgSw5BsFl09XjNy3cT/S+d/pKRQrWKp4xK6wsFEAmKDIKGINwmOi/NdNBdDjDkVnPrmGYz723H/p59D5+kcQGiaONrBSNIWBq3LurbmA4BU1AkQ6uAruuZVX3nht+HOMKVKMgAQDpc0QylQvfPv342l0jGYU12Y44nk26k0XnTKsF0PC40zQtrzWwHax3twT4/g0b85rLg/5P2kPVUyq5DfO/VrrTGlhq6tiMtMZdGSuYO0IjpYNwumWBMut+IgSN+wWPBgNm3UWmNSRHz7/vcISHR6l+6TjkFml0/hpSPP4/Z9dwuA8rEJs1qzeAkfe/oPcCD8vFiQYYCEulBIa8JNykWCIt2sNBmoM2YrpXr5XLJ6hy2IrqYPA+TUkTPCydKDOkkspIvqlW10Oz1pfhJ3SxqiTLgOaz0pCzGl9XCkNC0J9bjsG90MJLHfQXM+QdiljlgBy0cMRKdCPP7x1MVqqh4SqnwVYQunTs3s1fIp67J5NxMg7Mp5YF3e/iLedJhLlV7lTLZHV6R1tZzu1evefyPqN5no1ZuoTFtoRw0hylFIwAhTMl/cw/JcG/68j/CMhdZzJr754VMSYIqwcuSLW8B0pe266Plt1RFKEegbDezdNymFQ2eEInIuxNUq+BKwi6vlRXC8EopuhFao6iexFYEA0enKLeY0fuS+f5gVEcnwtewkS+fmayAEkFggw5GqOjsMlzB7WQAR9ytl+a4lQJZPdaUFVwBC+g5UJotJ12ysc5qM9KjJJWkWNcAoNH1FUdlv4qY3bRIxbDKCwzEDdqEvxl1o2ZifsTHa8DDz3BKe/Ohpmb/IpApHd/PzNNuXGa3ssy9ir13GU+7lVbmmI50HpHnERCtqMxO8ar6d1MopoS4neP87piTPzrtQabsDp8ZmAtVJUKqUhDHaCXiXc3HmyDxKvbKojj/92RmEL1Ha34YH+vKKG0VfOgOIlshNM1q1zQUEbi9ztaJCF4WiOxCLlOwuurYjcYlJRUbLzNKwY/4Exo3xjNQI3xEqCRMEuorOf+1ClD2mLQyBdAxP4r8//Bs4XXs+iz94kRmo62yWeDRamCFnRS4WIAO093wMkrpYDNJF5WTeBAFy+HElTq3HMLDFmUSfAW1kGrNUONxL24plM5OBTCrQLkNUXba/ZgxL9hlhJ4jx68aI7a3w2h5mHn8Rzx44laXkObydfOz8EuBl0veXsf0v/JL3cQf+H2fFNdhqeE0WTXK/syw3hZUto7qXnPR0F5j+9jpuuHNcZlVQaTyuWohdMkkTYY+22JgUx/ADOwMHMyHPf+E0Ggdi6bb1UJNculwsfvvIhCe0aha70uqtCUzdVkF9SwWsrtOKMBYhQJj2ZUaLNRH2n5T5GsK4oNAVFAwFEIsC0TZGO2MStP/o2z6A7fZNwtli4C4bPa2i82fe6UWMgbeIMEAnXsSie0wAcrLwIjpROjRE2mt7FweQdNCnbL60HkLrlm+cWon2LkH6CgChhi+bpxjDaYAIQIVQOCQeLpI+KsZ0EcPnhC+ab0r+MDG43UDlBge3vn47/EIXZVtNrSpFNcweW8BTjxxC40nFn4OIU6jBo2reu/KP84OD1mnz/jy3yDXtQc8a9+ndsK9D3GgGfaqF1nMd9Ky2xB23vXszxneSdduWlC4F1AxXMUTr1TI6Sw20Oom4OO1DPXjLdTzylUOqIrsMlFgRlBphV/GwuKKUlyXEovQiU/Z/m4EbbpwErUhY6g8+KzkAACAASURBVAr9ZKWMlgaJZdWF3sIe8cAL0XS6qBo2El+B5I3T3yaVdoJEN1PpoFw2GSVEHUtAQ4tCF+vZ3qNSRV8uHxNQ6MU0rxmZCNKe+yhhVV35Nro2MlwP0SAZKBiukMmKu5GAlYxexiDagjQWOgiXbQUQNjoFqk4lrGh9YHnBkRw7Qt/3VQ96WuDjpS4rRclNO0qYnJyQmfJHjhzH/JEekk4aU3XToFw+g4+lzVMZA2Pdslj8wP/Iw2RL2w+vEwIv/LY8gtSlsi0FkEyNz1UXgFkQKoyXb4oxOhnDrMVIvJoINzOly9WJeyiaHmZPLCHpOKi06jjwhcOKRj0fww7UVCZuPTHNOYDQ11KOXF/UjPSTzbeWMDZZgTkGMFgn/YR1kXywToAUDA+W3REr0rVi2AVHAFKxXGl9rRGYJ8q49+a3ZPR4HjPJjWTwVl1lUbhYK+ma83BdJwPIfPGg1D7yKw8Q2Tp5N0sH6qvUQzJO1hBAtEYW6SYECEIbwVIiLpYGyKHHTyM8qqrpWtoqO65zWBG867HCrp4xrGEmVBF6V/n8DONAflUJa/LgEPir9+PrNBjXL83LD/wjftRfAWBZ/eqv9ITqYY9a5E16Oyi+wJNnASP3uHjdu3YiKXdkTh7VBROjBKeQoFoeQ+j3RHLG9hMsnAlhL7jCu3r0L46puXuwUeqVMnAI74nflqhIXQF60vRnZWw0PzttydWFw2F+1nDhkAAJqLjIOIQUdjfuC7n5IbZiF8rdirTnsoeEHYhczHA9+Mj9+PCffwyvvmk/fvSHflxYvBa60mr7X5/8DfRKs6JieDEAkW2UJFIE1QVDPqbrIdqCUHWRsqMkLQ7TTfIA0XQTdhbSgghAeE5pgM+pP6wgE8p7HE+2Tt3Lv6oAzMUiML2/bHCoVls0THgOkydESxrU5GVHrw5APsUteo2KhPnBMFQCp2+p0rriW9IwuEoX9u437ZagfGRzWWZ1U82c9Q4r7a4TC9IJsHSqqUQIjjh48JOHFI+nq+flqTswXbYg7AjNhJ/VIxgS7WblAMJekR1qyM5qcYiurEuAXohgUdpQA4QWKlVaZ7PSqFtGvOBJ0H7rq+/Gt+99t6idcFEP66d/4mexffsYPvvXX5CqehNn8JknP4K/mPmTDQMQp1NWdJMjim6i6h0pbBNa4T6IB9yu7Dn93nOdAVNBNt/GVHPbOS8kG4uQvyXkFBWHGBfrVCjkh3+NH/UMgJuvvvnIAYR3g8CRIIw5bg6mjEgg3F3Aq75nK2p7DSwGiyjUi1LBZreaWe6B9OnWMoe1uOh2ArRPteEvACce7eHop5aURe7pORWpHFCaFFNKf2wXSYtceoZGkg76zI1pY7ehTveSBu9UFD9Lp3uZ3nVcV+aJ2FYJntWBZ6vCIIfajBfKOL28hJFiAdVok9QM3nrrOwQkjEna8zE+/5XPShfhD37fD8Abo7Wbl170P33hQ+jWW7BMU3UQ0vBxSk5aSc9ft3wsEoeOFEp1f8iwBdGB+kqdhatZEAJEROAOt1OAcJxzeitPWLeKB3QAJN7Q7lCeixozx5Ge/zy/iADRz2O6nfmxVGSun79SFJe+QOD6cU0APMuj5Igi1c1yOWsYzee8xwpmV5vm/MkLlbgbF+sAVBy57bv2wNnkC5WksrUEn0WkelHiDiqL05VZWmxLarc9q/g7WUqXgSRvTr2UPs6sk9j0UNwqigNIt1omLqeJk+kJpy+cDvokDZ5xiO4T0XHI+QAi1squwLRdGXRDJXYKqlF5sNNpiKgaQfJ9+35U9Hh1HMIYhEE6i4S61bZTacB2qKV78QBhFiqveJKvh+QzWasBRE/BzbtYlwqQjJKexply/nVHYHo5eH6ELq/MiFr8mvw5116rANIHh95mqo9msEfkcrbxKq85wcO4fJqJ/uL6yyT9O4PsRZnfnRaBMjOrAmH2FIivL987rX9QaWTcwJ67pzD9mhGUtjmYwwkhuVXqDiLTRWKamNo0gqJVwrHZ4yIC4Lci2AuGDJF8/AunlWvFk8yKuXy+5HNVgJdeJBVgpnxpOX7dj6KOXI+LZrp3603jkskyvTBrx2U9RFfVYzcQ5jCpJ7FpDNRDeLM3LMjQGbpkNh8IXYmXaE3u2fNWfOe+H8QkdsHsqlTnSgAR/S16nUEBmvKetyqrZbJ0A5XQ6ymGkPaoaxGHoJuKOviW9Jhk/SE5yjv7Svy5RCjvp55fkhFrml0riY1sV6ufUiPd33P5m2h6/rM/Dv9t+O8DOzdnXrLH+flrps87jBOOPJJtpCo1l7ryAJHgSp2cAYIhQcBsFKPGvJkl6NM9SZLgyBZXRqKN3uCgvLUE20vQ8Zbh1mx4hXYm+z9anYDpRKIFS+vRbShwJGdKfeU+hhsdpSquepq5aL77Q+2zu9NA5oUHlIKJQTEH7dxWwebpccRjfYAMZ7I0BX4lgFipARsAiD7PoYvifBXf+eb34vu2/Iioo5D5Swt6KPwG/vjAf8Jzi4+Li0UldTt2Jb3LxRTvhQCiuw/ZYbgaQKI0k2VcCkCeoIaPvqms2+a81N24Hs/vcjdwqw6WKC/ho/KA0Orq6h5MQKQ8HF7TdN4da2SbOHpgckJaYtv2krozF1yMjNcEGHITcbsS8LoVwC0ZaLGQXvGweWpcmv/nZhbgtwOYSyai+RIefuBFtB8IlWIfO9PitHVVilgpeS4fLObdPPlAbUHOBcjEdHmAAk/g5C2IWEROwrUTFaiTvEh30eLsEHXvGQYIW2WdxEZn1sLt9bvx9tvfi9dNvk1qJJHdwrHwOQHIoeZhNMsns7hjGCB8b+16aSuieVm8J7E9d00B8s0G5p5T/egDsz0uYc+8jJ56ZU2LChzcAKqIFdiclUc9KFUEsoomJnaWUKmVpeBWnSjBKlkol1XVuW0tK0sBNYm14Kqpq8zBM41KJRHXc0UYwHF9FItVxKVEMlbNhTbCVgJvqYJjX5/vK2JI3NGfSZFZkGG9Xn3ju4AF4SSq4R6RCwKE0qWmoRi+lg3HUAVELnLKCA4t38PaDY4XpNr+c/f9Upb+fbH3tBQJz+AwfKd9SQAR0KSp3nUDSDaR6Lq2IAOh0GUAW6VHSSALzJ4aikJvatzA1I0lYcRO7diM0GyjZ6tAjD/LjPG0p5uWgsJsXBRp8woURrCzAZMTtVEBiJfKWnW6qsfD8MtYOhMieMFW9Q7SH+gVxSbsoJK2ZqrinzA+eTvNB35XESDKgjD+MJR0qCBFxWZsN7WaHja3duGtr/oevHk/u5+BA+FXpdX2SgGiWb3DOlk6BrlkF0tbkFcQQK7AxUoB4trokSuUcmy0VhKpGZxYpNVBtOtEhRDfrMGNl0VORx4PDdGF5d/4mIAk8YUhyxTq+FhZetKXmzEKpKQELk4+v4DnP72IxmNptZap2U6/CEX+jyLSpfFHLplwsTHIahZkmJM14GINWZDVAJKk1XzDNzHa2Iop/wa84TVvwB273oinwsfwJ1/+Pfju0qoWRHCWS/+u5GKtG0BeQS7W5QfpEo67SifJaAslpHSvjVv2Twixb8k2MF4YpEjwolIhpGV5sLuRTDUqY1RcrbbVEG3YpmnAL3Sw2YlxKjCx3XMkQ6QVRKh1dezwDA59Yw6LX/VVFEXPzlJttJoS3Rc/vnKAMM2bz2KdFyDKm8pcLNtUo5N1Fku7WASIVUhEu7bSqsngmW2FG/Cmt71dXv+7X/g1FKrJQBU9H4PkTf5KWax8X8iaW5BXBkAkSL/8NG8KEFEccXzpoxh7fQWlrS44qWnLqIUkvYXZEUcJxIgdD56j8tYEA1X8zJ6BhrWMuGghTGVwlk017ZWLAIma1IFKsMXZhvmZHh76wlOq+YnhD8EhLZ+WZBtIsSY4uCRZoCkKYqpWoEgMpHkHg3RtQS4VIJr2zixWbITiXq0EkG4So0wXslOD2TYEJDs378TSxFGcPDGPyOtKLwWTDgzGL6ZIOEBYTAuiBAhHtVEGiFKkl+Ji5ZVNTqUulpb+UWne6zYOkTTvFRQKlQVJ2NNdCqUZZuedm9CaDFGoVVGx55EkWg6/L/FFIIjbEfQk21OI6uhaSwg4EpaPuy1xwbgqRhf+cixWhlTo40/P4ImvpXQHPkFzgga0tfgHTU1IyW1D4BhQ5rsIgOSFHLTLmKe9D7tYLGJq2vuwBeGh0IpwInJP62uFVdR749lNga4Vi6EcuWbaNmIWOJkUSbNzOnOlX7Aqo3cVgMA3B6bfZmneob70fKHQ6Fh49lHVVyPcqcw5uG4BIoXCK6CapM1HolAYo3q7id33jKJR51w/NT5gwlSkvFZkoUpZPrnKtDieTDPicskrSR+jddHjwPRQyZpREV2r49+cVw078zGMQEXt0mOQKwBmO0x2Ye63nOXQVdmMqr3OANFZrKxQqAFiJui56sZRCKsopmPT5HvZjL/STrzc19AA4UN5kKwnQFgo7J4KkAeIdGXKDPTr2oII1eQKyIrKgkggXAzh7ANuee2UWBACpFZXw2cKdgVGOpG1FzayCU6FpIxKnAh4Ct3lbBvYqRK7x4pzXMLikYaSnDnUVQVAowTLV33JYr00XWQAHUO/ZADRpDrVCqoEZlevg6zmYq1UB8lEHFLCorYgqwGEqV7O+Sga/WE7BAnBwUKgHrM8/LUM0sCH1loDJGgruvtqFuQVAhAhK14B3V0BRGIQFsV2Up91HIUbYiyVDOQmDlBGUPqKgzCEI9QStRy/P5aghgQEhdH00OsF8BsBKBQwe7StKNZS3GYHoinN+8qC9OdwnDMPMsfl6TM+89ywHEN0lULhSgA5XyVdfSlFeR8GCP+k07z5Wgisfp3WStPhyoqcyzHSsUgeH+eAg3+kIENu+tRwDDLsYrFRKq+uuBpARF1RUurs1ZAPup5jEKG7X0HDlJIGlbs454uPmNj22iomXlUS8eczbjQABoKjFKvYgqvUCmE5BpotD1ajg6VGB43FDqLFEJ0zCZKWoSrj6T5W4FC/9McLkOyU2+j5nTMQkK8kbTpI11YVztWD9NWapvJUk4sFiDwvrYWony3kwSEPpaxd/qwD9SHDIW7WlQDEjwO4gYNsTkgagxAgekYIg3TdD5J1FEoz03UPEGmYusKW23SDcm+lMyN275uCtbOI6mgghcF2XIYftjHSc9HxC7A7bSwudGG0gZMnlmBw8tAikLRZD1HtnAM3pvQmxTpkdgcOEiFDcmWkQ/6Sp5Nku2nIamgOmTJBap2HaqK5WOcDiBaS0wBhJZ2PsTc9X0nPxyHZCAPLlnkfsRnDSrWlNDicNHEx3FGov9paAMTqccJUf9JUr9uWSVoaIH6jJwrvzfkAxx9WHZqqTzwle16/WSxpub0i0QbtHIgsD9s+LaC6tYTKTgObpyfguh5aWM6sg7fkIlyOMX+6o9TyhhMgNN2yYdOdrhm/bKQZWrorTe1z/p3ERH3RziWYrdrEM5ABW52sqAEyTDXJKy1eCkA0H4vxhuEYAwAhT4vLMRXDV+7VVltab0VCJ12MR67EgoSisE7p1AsDhCMQDj06k81Y6YtXX7dZLBFtuCLZH61KQpdHuFjMbFCEjdeXtBPRpgOMwJARW1K3oLrI8GTWlC8ZwZDGKb049qC/0tu9BNWqLE6AsoFmECDqFfkON/5+cQCRrajUN2xg6o4+mzcPELvCTW3DpQSp4WZSpEJ3t+IsBqGXxJ4TTTXJ10IE2LGJxI6gpx7QYGjWbh4cqwFEHg+YyEubqFJBaykSStckxwrEmaqJfGYEdIPVW261BckLx0VUeX/lAURkf9ZYOC7ncumd3b+pDzTMnDslaDW+/7Dt4B1rqBFL3WOHn7jy7/n0b4bE3Pvpzra0L3361inpBxGAjAYymo1Tp1gEdWoOrLgoUqTC5i1aGZMXHBGQcq/yPSFgFyPdKY6p5kg1BumUNuK34pwN24YXejCjklD72fvCRV3eOLTRiBUfrR1GKNnsK+emV18qnRsqwJObQhqzDY9B0D3p2oLIczucB0FPwAda9srSo48rbV5mEnuStr+ug3QRjlsf6dEVY4GL279X91krdDzqGCUFyPa9UwiKLdV2m84vdEYBu2jA9JVonAZI5MWwHROOBEx2NoJ5oHGKWa7Uk2SmybY8wO0JOGSTpwBhE9Z4XSU1ur5iBnA6U4cjsviY6aIQ+32AxIkAjgRIzeLl8/LttnIbodxUKtogoEhX4PsIO4kAnzEILUhvroNCOIrubKDabQ+1FbUnUrKx13klXaRHua6AbnJ1t/Oaf1oG5CELwsfTqUm3v2Y33O0G4PQQVyLhmdHFks2XjmZjQB6bPaWwmHOxZMOnb00rwslX0KncdM5gaAawPXMQIG4JU94YvErf3ew1A5zuzYtMqq6s65pIGOaGkTHFm7bnykGGamCP1ufNj0BgMoFub7fbEbDTerihB79lSA2EAToBcub5hirSMqsoAMkViS/Wcq/5xVvXN8zEq/kpV1AsXNeDXP83Xwkgwv5N28iosnhHBTtfvVXYAmGhAavuwC6H0nLLmOIctXfN5k177FkP0RZEAMJFkOTMiI5DtIs1Xd0Od6yOsVSxUZ+I42dmsLxwRhTeuZkHYg9alVwyg1R2rkLsgNVwgklrYrmhKzNNqCvMAJ3CdJQB0uMPwpaNaClAORlD40wbTx44Av9gv6XAD8jkVlJJF+3arv/VXMtPGBh/cI0G6Kzl97nM9zoHILnUJYMkNgamiu/Te7bJ9Nx20ELTWYRTN2QmOGVI2ZdOWr7W6CVNXy8nnRVu6F4Q3tQ5ZDR2ULJs+Eks3CxmsggmxiYT1THUx6oYrfX5WXy/UydOYaE1LyMVuj5dKh8xY5qUehKk4nt5cLBIyJHLmqCowdGNEyRpVZ796J2GAbOjCoZ5FgPHHsw83xIRaWkUFZqJzo+vq6rIZV7UNXnZwACdazSCbU2+yJW9yUCslBduyFHkbaDKNuGbqpiYrsOrpXP/Kj3Rlc2G66SK7zLg00kQp7q9jEdMUYlkuUX5W3aqkmfHqiXXdUKEKS+Ls8VZiedE2IJbQOSasHyVgGg3Qyy2z4iKfRSKKgV6FB3OLQn8e2nvOse95eYTanCwn4aLA0g7vSXp5HR6Kt4RdvVcSwSrM4qPVj6VGpU2rwLL69WCDIxgu/whni+bYHwVHK0AkAHFeaasZUcra2JvMXDrq3fD3WSJNZkNj2aSpBRgDrxlaR0mQLJpuClYJHCXXcn5iSlgIqV6IhrDJl2WSAXtuZUYPZn5oZfOUAmwDFMskEhTxIbMRKFyCUHB5jGuIKjAN+bAuei0GJZPiRP1fssLdLH6FsMLCjh9claG5cwebyFeTpSsh04QZn0gOdbB9RmDDAzxvPwx0NcVQLQgs9qKrK+YTqi0grXuCzeIp0SXxzeVs9jE8xzpt+eStmIO1fGWMxV4TYfX4nJ8Hke2+baaWit37lQiKBqSGZVjSXs5shhGwhgFOHZadi0Ky3URRIbEEgy8dYMZleIp4qYlfRiw01rQUgj2mxUszC3j2aOH0XwpQDQLJR49TNZNvUbRskrp99dp/MHTMjAGmg8cBLB7lfvs9fvwEMCVYnm++JiKWg/rwuZKNtXJEtwSMLK9ilqxAtRDuFUH7niMFhZFidEnj0amUan6Sd0bESvTTXpSO2GgzGDfb7dFY4s/Mxum7/T5C8CNrxddJK6m3UAU+5kKPDNSLPjpRjX9+ZsKW3H60Bzino3eaQNLJ5uYW2wpUPRSsb28tcglx7IPHabqnKPR+7LfLofOchRvVPugvz4M4H0v+692qV/gHAuo8vu0HlyqQp+CRGe38meNm0OLYKfyRnoY6N7XTCNhnFJpKhmjNC3sNxVVxGi5KI97oIohs0YjdbXZq0YVjUQpvay0wvTOzwayVqsjFqvlLkoBc9FWscUm7Rqmb8A2ZxIQw9MGnvjMDKJZA1EzlWVifKFBwe8gaVxN1VE3jExbTJ8DfWArdWhe6jXYeM//07N9Uu8fBsgHAPzmxjvW/7+9Kw+OpDrvv56j55I0s5JW50rsLgu7LF5gjRcDCbDYhU3YYCDGlcI4BU7FdlyOQ6XiP5z7chL/kyonTirxkQTKgVS5XBDjEAMO5rIJCcdeLLuwLALtrqRZaUZzaI6eqzPfO2Zao5FmpDk0R3cVhVbqfv3e975fv/e+4/c1u0ccGAQS47VMQSRAjP+nGDInpzWVZ5Ub7rkcveNWuAesSPdE4LA7GG2RFlhCKq6zJLDkrA2B9yM4eyrICLt7M8Xwf3q/xSm2USw7unhltGIofEpNYWJPP3xX2Fi5ZbVfxeAWvickgm9K5aWLyLPPHJvDaw/NshofxI6Yk9GajKmoWItcfiDoOV4gh7UgCPgMHelMgPwOgG+UAuQAsVk3Wx1b733LgcG9xcbLkMpLEcCSvJluIeuVXEV6LLj5S5cy+lT7SAJ2r8pKU3tcKoKhECj/gkjjHDNeHH/2PE6/4F+5xZEW55Jg5EJv5FdfBSZu92L/we1Iji7COZhDv6+YVhALJBCJ6Mj5swieTOHIw/PI+nOsoJCsl0IgMIJCfiTIU74CIJ2/xboGwCulAKF/d69HfVWklov5MtzsEp5lskrRwdUJKA4FVh9w4xcuRXYoCseQBcpgFj1OB+xeLxb9F5CJ60DABs+FAZx62s8BYgz1l9Ss8lWrdIN4wFKWHCbu8GL/xycR7V+Au1+B06fCoVK8VBzpSAaUsJlZsCF0QsORR+agnNML5eiMJQhk+IjcWtLrKYC0UKPDaLGSv269r1wtPWIedNlAadjeYwDurKX1zn62jJYaGVNImgIglHJ89X2jGL7KDb1fQ67fji1OJ3IuO8KLUWRjGtLzOdjf78Wp//Zj+oWwobKSIU/F+LUuI1zVuhwg2tYonEMZ2Fw2BkaqP64nAW0pi9hMBpHjWAYQTo1U3K4VC9usyEMQb68yILR9FeE/ANy1GkC+DODv2ndsdex5uYhfY/MswYoK8jiRJVZ0uU+ncFoXYBtWcPD+3XBsTwODUWQGrCtXkHkrPAuDbAV5+6dzgsLIBkXnhS/5RYWOiSWf10+hi6cApLmJhf5zACOf9OKamyeRHFlkq1WfxQUPATJjw1IqAi2eQXIGWDyaZQChtFk65GfVDDQi9ytniaK2RVSw8RRftlBOHUW/yU39NoBvrgaQPXlL1slN7mBrvL5agAjNovpYrEoS/dueZtWprrt3Byv+kx3SQFZd+VXXAgGkIkByXodvdgSv/OQdTD8bZhRGxNZCRYTobMC3N9KKVszjJ4BQ/g0rJScqcY3c5cW+m/qgjOlwDYCxU1K4SiyRQjieRDKWRDykIXY8jWMPL7Icf7Y9oyQ3WSlKjlli03jGKsR4UaGc4lXOCtwaE7jhXlwmmH5YA+XU4E0AdJN5VZQALyEt6+xxjbZT/AbUyxRc9alxeC5V4B4CVJcCb28PXHY3/OEFprR0BvGdH8YzTxznDJGkmAlZD5zHdhRqrLD9PjGwcIWW/hrdZkHOkcLEIS/23NIHdVyDrV9lYKQzCF2xYIatIrmQgtBbUbzzcgqxV9OiWi2nj+WFaJbn+hPfgLzYqsWyO4kyvpit2WEAocVhr3HaywGkxhz1ilrVUTdQ5VamxOKzqmTd0K1xBpD994zCvdMKy0gafQ4qVc0BMhOIFBS2f3oMLz16CrP/F+MA0ZYDRJPfMMn9xfdYoLqHdHi22BTGarn3U4PYddMoMr7z0PpV+PqdhTMIJV8txWNYnE0DIR2uuA/J960In4vj2DPT0MNif6VSeAqfHpvqhqQx4680AITMx+KRDgPI3+R9rl+pBJCbADzXUVrcwMGUAsRhdTMib/uVwA2/uhvpHSHYfBp8PX0MIA69D3PR4DKA/Pj7hxF/XVjD0kWA8NVDJpMsZ4gkgLAFizjBnMLMK6xYfaNWlluye+ISTAf8QDyLhJZAekmHI8298MmIButiP0KnUzj887ew9I7OwkvcFiejVaLqsqxGfQElRk+i8aDeUYf2gwCerwQQ+vs0gIkG6lXHNF0WIHocvfstuO7Tu5AYCxcAMtI/hEQ6jsUI3/LILdbTDx9G9ASl+fFipnS+sCIttlckKpHGLM2qhS2ODVnymHsA9z4LPv75j2HBdRhbxlVGij0xvBNu1Yo5vx/JcFHkUS2KdCwNWzoFJbYFzkUfX8UOxwqGAl6COVlSuVZGOxvDDzom5fYsgMlSxVztKPq3AOg0b14VJGCDypRZE3sOtoIocfhuUnHgzhEkBzUGkKG+QfT7fBwgixoy6RSSgRw7pP/oO68jNSVqj68GEIYTcaBm2xt+dmDVXu1x2HYquO2BKxAbXEDOF4NvgFfZpVWErnAwyhyUSSTZ+WQpqSEVTsCedCIxl2PbrpMv+THzfJSTa1BWr6EarRQDGSO4X0ReHRPuTtbbB6oFyA0AXjDRUVkC/LCcKZxBJEB6f0nFtYeGkRmkL3yiABCyKgVCQWTSFlYY0zM1gie/+yovAETuCAEQeWjme3zDNov+WQoQB3EjZzBxqxcf/cxeRK3zyPZoLJGqx+3B5MQYdNWNxFIU5wPTLBKX8tlzqQRzWFqjQGbRiZ5ML959aR4n//MCshFO2GfVltecXA4Q6kjHrCA3AnixWoDQfaY1qzI+mDUpS5pN5lbSFaJVdWSw985BjN/gKgBkcEs/tg2MIRCOIBBcZHkbmfkccm/68MJ33+QKuSZARNyJsGLJnGBWW96TQzyTZMyWN/7GXoxe4kZiyxxsXiuCeoId2HdddDkbDYHk9Pw55qj0OhwIaxqcigXZsIbIOSAbsSB6WsfJ5y4gM81XNUqOlIVZi2R99GHoGHCssF7JqV/L2v+HeWPFX1ShI11+i1BcCRCShgfYd88wtl7vArGfKGoGXp8TY0Mj8C/OIxBIsPwO6wUHoodVvPDPJ/nen0XRUkPE98W928UVxAAQtooUq98ySAAAD4ZJREFUo46ZJ5xC40VdyFvu+yB8V+egOReQ61MQSYehel3Yv2MPS+GlvPbQfIiZmonulIjnIpElIOaCO2mDNe6D/7UEXnvyDOdETlPzvHIXmbQL/eqcUJM/yn/avlZOkdcCyA4AFBdvXmtJgKhCdRGkSNIkPXYBNzywE5adSTgHVAaQoeF+RuHz3tw0UloOyQDgCW/B2eciOPzo+6JKFrWlFJyAjK2S8VoZUoGNTPbSwSfMrux+KvnsVbD3o0O48tBF0LYGMWdZgpPK47kV7B6/BOODQwwkwZko0rkolrQ4HE6V1UkPn4vBlvPAEx7A1NE5nHjiAvOXuFUntBiBlgOXvYsSyTojF4TyoKbWCxC634zNqvh5EF92mYFKbJJbFRz44ihckzocXgfRimB4q48B5Mzs+8gmgeSizgBy5skLOPG4n+9WGCG08G1kUsxjXVxB6F/6ylIP4vW8fqqTFy2lqrpbFNi269h/xzbsus6LhWQAaWcSbocbk8Nj6BsZZowpx49RnhwQ0eYZVRDRD0Vms4i9F0NPahSvPzOF0MtEJFek+mGOUXqoM1aQZbFX6zmD0L2fAPDDijrS1TcY2OVJWVWwUnQfun8Y6rACtd8Ku1PBtq3jsKgZnA/4OUACORaHdeKxOZx5TgCElRRQuMeaVqXCJUkSygBEKCkHiAjMYv7GJMujpxz6S39xAFccmkQoPg3rsAV2jwPuHnfh8D47dRahpSArXU20QUrcikwoi9RMDqm3PXjl8TPC6865sHhpbbFqtr8b5A4Aj6+mwpUijug587C+5gdgJUBGr/Fg313j0Ibn4ejzwOW2Ymx0K2tl2j+DjGZjCmid8eDov8/A//oSX0HY+YPVhi5sZfgWhg7E8nMtylmLmbOQNYpKSRsO0vyMYEeGrFv0qBUY3e/BzZ+9HGFLALqHAhqdLCT+ktEdzMIVmfPjzMIsez1RBmXmNGQXnNDmFBz94SxSdGCP8HIXvHIwq5ZqIDxuy6/kqodzOZpqAGJmGq71eWEBfWIvTgpjAyZv8WL3bV7mA3F57HD1OrBz2yij7Dm3OI1swoJ0RIc+1YOffe9tpE7qjGuKGEd4SIeBxscQd8W3W8sBwnBDB2hxaOeh6xkwql4ZnU8hVVR86GIFt3/ug0huCbEIY3hs6HG4MbxtrHAuOfXeGcSiWViiOrTzCTiCg/jfx6YEQGh4qohc7giAFDIHa1lBKDZhLp+C6GvLb0QjO80+6gaAkELagcs/MYz+jyjAgM4B4nNj5+gQM/GeD12AXbMhHQCi7wCvP3SeFcVcARDx6eIEJzIvnH5JVO4lg2Jpr3ZQHDCFr6dzGeSoqBHdJ4qcksdfs+vMoXjrfR+CvmMO8GpI6yrbAu7bt4utJIffOMIA4oUTkXc02OcG8OIPTiDzLrdmOeDkWywyFnAXULse1CkxiphLJONXWU2pZgWhB8kE9geN1LW2bJtJT2iJJG9Qgf13X4Se6zXYRhQ4XNaCiVcCxBq3IRXMsuSlow/5kZ3PgbZKy1YQAQJO0EinCxFKXwoQWrXIDAsbK0vHc0WIcUEcDshokFZAHHYaEXD1ZmDpU7D77u2YvMaLjLoAW5+FMT2SlcuiupCcD0L3u5BOjmLxxWm89VQQ2YVcYRtHFEJs5ZIpwe1pyfrLPLzJlbHmVS1AiDeLykUbUwEqtd35f5cAYbkSOe4sVIEP37cL6lUR2LZa4aE89D4H28aQ74FWEPJcawELQoc1HH2QlhLAYhV0nvL8sUz5JJO6WEHof8ZwKMqZ0p1IsTopIupW1jdkZxu+NaJ0Ws2aZH20DCgYOtiHg7dfjHnrBVAptpSdb+LUtBVK2A5b0MO3gKd57ohirOoljGpl6863/szTQMcB+Ct1tVqAUDtmGPwKaXLrUiHq1ZqB7SIFV9++DeqeNNzjTljtwOBIH8bGBzD17lnGpxucW4LutyB0RMcbj8yB+95kZa3VvNNyXyVJI0RnCl/vkn2XrNto+DvLN6eMR3FWIkD7rlWx78PbMHHxIJayPNZ9yDGIMyfncepnU5h9Ncb6RysZFWylaxmJQ8GzX0nVWurvK8LaazmDyGdHAVDEo7mKFKTJWU0sVgtnGrTn2B7/4L27oYzGkPPmoLrt2L5rkBFRvz01hVg4Bz0GOINeHHlsGtPPhAVAShW+AQolLV8K/yFHtmFKDx5VMHZJH0aHaaMAzPr9mDkdQeacCKAkTOnck878LIVlo5jA1YDeNqpJWj0oUp2b7Cpc61lBqKm/zqcSfLVSo13zd5KeDEmiGCxLBrZJDhBtJMi2WH0Dbly0cxyunl4cmzqJyFwcasiO3sV+PPvgcUSPijB3KbRG7udLZ1v4bdirhatFoZIOxK4ig3TpkJ/lkcPLVo9CKau2O6R/PX8w/71qdXS9APECeM+0aAnxSv+dlDZhZEDBgU/yLRZZsWhf793qgGLPYSmoQ00q6A0OIvqujucfOsEdcEafYL0BsuYMi20d7ZxI4WVUC52l6KwvwMFNALwhtr0iC5Zxx1fvPlerveu/jyxX2yn6v9pH1wsQard7SyWUSlUChPSMjIXE0t6r4LJfHsCua8cR6b2ARE8aNidXxPlFYKd9N9T5EGcy+fEcB4fRG11vZTPO8Iq2bXDDjYRAKKt3L1cGFv5lI9MXAwflnVAAZYY6274AYSUNqgUH3bcRgNBzpnddSk9+SWlLQl9eKpGwXcGVh4YwfvkQI5WWpdlUfQCORJblXLz5lH/l6sE/0U27aF1wgBM7EEgIABTtkqMinoa68XL1oPuYI1IWOaVfELib2OcahFPRa16u7Y0CpKbS0TUMsvUeFc5C2qNbVRvLRydjj/0yYM+BYXxgP8/DiOUCWEq7ETsWwCtPnUZuRi+4KkSBWj62JiobN2bJ+C3Jv2UwwxgIrGWpbUZD1J4AIWL2769XgTYKEHqPGekL7p9g4ICKAkuhQ+yZRB2RrRNuhDMJpBb0gmWIwscpaYll6JWGsK93Fjd4fxEgvAFGElGyJSs1WXISCVHDUQK6iaDe4FDXjNhdq81aAEKfxjc22OEOeUyCg5SGKztd7CtL+ePSyiVHK10clMraIrQ5y0jgSh2QBv4rOYQCQOgXbPVsi6n8AIATG+lpLQCh93V51iFfQTgopCmKJzfxQNeVGsR/L7Yp9OfNDhc3akC5A/1qjshN73jV6r5qtmA1LdQKEHpH95aQNkpYVMTlYevLi/BwAHErEPdCixx2/odNBElJ+QY5HkMp6cpKtNkIX7OHrJRz5TGsfkc9AGIyoEhzL/1fmG3J8ywPtnw3UgwFoYw/EbXB/Q2bpmO845IUu4AP1qniv/hPq3Vy0zpfjd6XZSqp5kF5Tz0AQm39WV6Cf7yeF3fMvSRB0jPJLS3KlxXyJugAXthKyaDDFlpBygCE5oZHBfOf+E5RbAvFr5Z7CltyNv883+s/qbVn9QII9YMoGwmx3XXJg6087Yq4Jb56pDhflozMZWZTkdtBDjkJnM066AoTNauSRam+Ky7BeyUDH41/F+UfNnH5W0vPiNONKHRrvuoJkH0ADndXMKMhV5woQMnqI+hxaGYKrO8yXisLOHJFxnSe273J3FI0BEOdQYnzAim1/ABIewO7lxsi+LXJ/V8JAer6fgDHa0ZHDZ701d79OQDfrkfH2qMNuWUiSXKAyLyLZQCRukRJeDrPy6CLR8aWxpo0ceTy8yiUX5qeed8M2lFq3WptgHw+n+vxnXpJsZ4riOzTP+VDib9Qrw62fjsleRrMxMsPrgUlM359hXNRAqQltiiV/BmlWiKoT4srSMvM0rfy6eG/Wc/eNAIg1L+XAFxXz46abZkSqCCB/wFwfb2l1CiAUCk36rBJ9FDvGTPbKycBCmOnD/KpeounUQChfhIhF8XAmJcpgUZLgCozN4TgsJEAIaGYnFqNVg2z/YrcVrWIqNEAob6ZZA+1zJD57FoSqJp8YaNibAZAqG/fA/CZjXbSfM6UQBkJ/BuAX2u0ZJoFEBrHEwBua/SAzPa7QgL/BeBQM0baTIAQhenTXRmO0oyZ7J53UBjJxypRhtZLHM0ECPV5C4AnAVxTrwGY7XSVBCh8/dZ8sc3FZo262QChcRE7GW23rm7WIM33dIQEXhPbqop0ofUc7WYARIKEipaYK0k9Z7Nz26KVg4o5NRUcJM7NAojcbpEjsftC5DtXkRsxMjpzkCOwadsq4yA2EyDUDzq4P2patxqhVx3RJlmrfqVZB/JyEttsgMg+mX6SjtDnug6iKX6OSj1uFYBQP02Pe6XZ6p6/N9xDXq0oWwkg1Gczdqvamevc+xoaW7VesbUaQKj/FAX8oBkqv96pbPv7KWT9/kZF5W5UOq0IEBoL5ZP8i5l0tdFpbbvnKHfo1xuRz1GrJFoVIHJcXZa+W+t0tuXzdU+TracUWh0gNFYigvjH7mJLqecUt2xblLL/xXoSLDRipO0AEBo3UQr9velUbIQKbEqb5Pz7rXpR8zRyBO0CECmD7mVwbKQWNLftujAeNqvL7QYQkgtxAZPPxIzjapaW1Oc9FE/1FQAv1qe55rTSjgCRkuny0gvNUZA6vaWmEgR16sOGmmlngNCAqYjP10Qw24YEYD7UUAlQMCp9yDZUvKahPauy8XYHiBwm1Uz8UwCXVTlu87bGSoAKZtJ8rLsmYGO7tf7WOwUgcuRUovr3TS/8+hWhTk+QN/yv1ltquU7vbkgznQYQEpIXwFdFPffSGpQNEaLZKKMhpvrjXwcQ7iR5dCJA5PyMAvhdEQBpAqUxWkvA+AYAir6dbcwrNrfVTgaIlCzlwH8ZwJfMrVfdlI22Uv8A4JubkQZbt1FU0VA3AESKgbIXKbSB6keYh/kqlKPMLXT4pvovFPqjbayJ9nqqmwBinBkiAPisaR6uWlnJXPuvAIhoo6uubgWInOQdAO4F8GlzVVmh97RaPALgYQBTXYUKw2C7HSDGeacQlrsB3AVgoksV4iyAxwD8oN1CQho1XyZAykuWKqTeLthWOv28QisFsYf8SFQqbpSutWW7JkAqTxtlN94C4CMADnaAJYwsUM/lUwd+CuAnrZjFV3lKmneHCZD1y/pAXrF+Ic8xfG2eQpV+3rn+Jpr6xLt5ys5X8py2L+eB/nPxc1M70M4vMwFS++yRn+WqPAHeFSJ4krZkl27CSkMrw9sAaMtEwYHH8la6I53up6h9+tZuwQRI4yRMwCEr2SSAbXn/wZgg7h4E0C9CYnoBuPMhGk4AdkNaMXmo0/mQmSSAeD4iICpCOIL5TLwFofQzAM7lyQ6mhZWp6by1jRNd67T8/xDzS7sZfO9zAAAAAElFTkSuQmCC"

    const/4 v3, 0x0

    const-string v1, ","

    const-string v1, ","

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x0

    aget-object v0, v0, v1

    const/4 v3, 0x6

    invoke-static {v0, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v0

    const/4 v3, 0x7

    array-length v1, v0

    const/4 v3, 0x2

    invoke-static {v0, v2, v1}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v0

    const/4 v3, 0x5

    new-instance v1, Landroid/graphics/drawable/BitmapDrawable;

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const/4 v3, 0x0

    invoke-direct {v1, v2, v0}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    const/4 v3, 0x4

    return-object v1
.end method
